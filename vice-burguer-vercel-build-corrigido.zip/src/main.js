import comboDoubleBacon from './images/combo-double-bacon.webp';
import comboDoubleMelt from './images/combo-double-melt.webp';
import comboDuo from './images/combo-duo.webp';
import salad from './images/vice-salad.webp';
import classicBacon from './images/vice-classic-bacon.webp';
import doubleBacon from './images/vice-double-bacon.avif';
import classic from './images/vice-classic.webp';
import double from './images/vice-double.webp';
import triple from './images/vice-triple.webp';
import melt from './images/vice-double-melt.webp';
import fries from './images/fritas-cheddar-bacon.webp';
import coke from './images/coca-cola.webp';
import cokeZero from './images/coca-cola-zero.webp';

const IMAGES = {
  comboDoubleBacon,
  comboDoubleMelt,
  comboDuo,
  salad,
  classicBacon,
  doubleBacon,
  classic,
  double,
  triple,
  melt,
  fries,
  coke,
  cokeZero,
};
const categories=[{id:'combos',title:'Combos'},{id:'burguers',title:'Burguers'},{id:'batatas',title:'Batatas'},{id:'bebidas',title:'Bebidas'}];
const products=[
  {id:'c1',cat:'combos',name:'Vice Double Bacon + Fritas + Coca-Cola Lata',desc:'Vice Double Bacon, 150g de fritas crocantes e Coca-Cola lata 350ml. A combinação perfeita para matar a fome.',price:32.9,old:37.9,img:IMAGES.comboDoubleBacon,tag:'Combo campeão'},
  {id:'c2',cat:'combos',name:'Vice Double Melt + Fritas + Coca-Cola Lata',desc:'Vice Double Melt, 150g de fritas irresistíveis e Coca-Cola lata 350ml para completar.',price:32.9,old:36.9,img:IMAGES.comboDoubleMelt,tag:'Mais pedido'},
  {id:'c3',cat:'combos',name:'Vice Double Melt + Vice Double Bacon + Fritas + Coca-Cola Lata',desc:'Vice Double Melt + Vice Double Bacon + 2 porções de 150g de fritas + 2 Coca-Colas lata 350ml.',price:59.90,old:65,img:IMAGES.comboDuo,tag:'Combo para dois'},
  {id:'b1',cat:'burguers',name:'Vice Classic',desc:'Pão brioche macio e dourado, carne suculenta de 80g, queijo cheddar e molho especial da casa.',price:24.9,old:28.9,img:IMAGES.classic,tag:'Clássico'},
  {id:'b2',cat:'burguers',name:'Vice Classic Bacon',desc:'Um lanche simples no nome, mas gigante no sabor: carne, cheddar, bacon crocante e molho Vice.',price:26.9,old:28.9,img:IMAGES.classicBacon,tag:'Com bacon'},
  {id:'b3',cat:'burguers',name:'Vice Salad',desc:'Pão brioche com gergelim, carne suculenta, queijo, alface, tomate, cebola roxa e molho especial.',price:27.9,old:29.9,img:IMAGES.salad,tag:'Fresco'},
  {id:'b4',cat:'burguers',name:'Vice Double',desc:'Pão brioche amanteigado, dois hambúrgueres suculentos e duas camadas generosas de cheddar.',price:28.9,old:31.9,img:IMAGES.double,tag:'Duplo'},
  {id:'b5',cat:'burguers',name:'Vice Double Bacon',desc:'Pão brioche douradinho, dois hambúrgueres, cheddar cremoso, bacon crocante e molho especial.',price:29.9,old:32.9,img:IMAGES.doubleBacon,tag:'Bacon lover'},
  {id:'b6',cat:'burguers',name:'Vice Double Melt',desc:'Dois hambúrgueres, cheddar derretido, cebola caramelizada e molho especial no brioche dourado.',price:29.9,old:32.9,img:IMAGES.melt,tag:'Melt'},
  {id:'b7',cat:'burguers',name:'Vice Triple',desc:'Uma explosão de sabor em camadas: três hambúrgueres suculentos, cheddar, cebola e molho Vice.',price:31.9,old:37.9,img:IMAGES.triple,tag:'Gigante'},
  {id:'f1',cat:'batatas',name:'Fritas Cheddar Bacon',desc:'150g de batatas fritas douradinhas e crocantes, cobertas com cheddar cremoso e bacon.',price:11.9,old:15.9,img:IMAGES.fries,tag:'Para compartilhar'},
  {id:'d1',cat:'bebidas',name:'Coca-Cola Lata Zero 350ml',desc:'Coca-Cola sem açúcar, gelada, em lata de 350ml.',price:8,old:9,img:IMAGES.cokeZero,tag:'Zero açúcar'},
  {id:'d2',cat:'bebidas',name:'Coca-Cola Lata 350ml',desc:'Coca-Cola original, gelada, em lata de 350ml.',price:8,old:9,img:IMAGES.coke,tag:'Gelada'}
];
let cart = loadCart();
let query = '', selected = null;

function loadCart() {
  try {
    const items = JSON.parse(localStorage.getItem('vice-cart') || '[]');
    if (!Array.isArray(items)) return [];
    return items.filter(item =>
      item && products.some(product => product.id === item.id) &&
      Number.isSafeInteger(item.qty) && item.qty > 0 &&
      typeof item.key === 'string' && /^[\w-]+$/.test(item.key)
    );
  } catch {
    return [];
  }
}
const brl=v=>v==null?'R$ --,--':v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const esc=s=>String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
function status(){const now=new Date(),timeZone='America/Sao_Paulo',parts=new Intl.DateTimeFormat('pt-BR',{timeZone,hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(now),weekday=new Intl.DateTimeFormat('en-US',{timeZone,weekday:'short'}).format(now),h=+parts.find(p=>p.type==='hour').value,m=+parts.find(p=>p.type==='minute').value,mins=h*60+m,open=weekday!=='Mon'&&mins>=720&&mins<=1439;document.getElementById('statusText').textContent=open?'Aberto agora • até 00:00':'Fechado agora • pedidos agendados aceitos';}
function discount(p){return p.old&&p.price?Math.round((1-p.price/p.old)*100):0}
function renderMenu(){const root=document.getElementById('menuRoot');const q=query.trim().toLowerCase();let count=0;root.innerHTML=categories.map(cat=>{const list=products.filter(p=>p.cat===cat.id&&(!q||(p.name+' '+p.desc).toLowerCase().includes(q)));if(!list.length)return'';count+=list.length;return `<section class="section" id="${cat.id}"><div class="section-head"><h2>${cat.title}</h2></div><div class="grid">${list.map(card).join('')}</div></section>`}).join('');if(!count)root.innerHTML='<div class="empty">Nenhum item encontrado. Tente buscar por outro nome. 🍔</div>'}
function setActiveCategory(id){const next=document.querySelector(`.chip[data-category="${id}"]`),current=document.querySelector('.chip.active');if(!next||next===current)return;document.querySelectorAll('.chip').forEach(chip=>chip.classList.toggle('active',chip===next))}
function updateCategoryJourney(){const sections=[...document.querySelectorAll('.section')];if(!sections.length)return;const guide=Math.min(window.innerHeight*.38,360);let current=sections[0].id;sections.forEach(section=>{if(section.getBoundingClientRect().top<=guide)current=section.id});if(window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-30)current=sections[sections.length-1].id;setActiveCategory(current)}
function card(p){const d=discount(p);return `<article class="card category-${p.cat}"><div class="card-body"><h3>${p.name}</h3><p class="desc">${p.desc}</p><div class="card-foot"><div><div class="price">${brl(p.price)}${p.old?`<span class="old">${brl(p.old)}</span>`:''}</div>${d?`<span class="badge">-${d}% hoje</span>`:''}${p.placeholder?'<div class="placeholder-note">Valor não legível na foto</div>':''}</div>${p.price!=null?`<button class="add" onclick="openProduct('${p.id}')" aria-label="Adicionar ${p.name}">+</button>`:`<button class="add consult" onclick="consult('${p.id}')">Consultar</button>`}</div></div><div class="card-media"><img loading="lazy" src="${p.img}" alt="${p.name}"></div></article>`}
const drinkChoices=[{name:'Coca-Cola Lata 350ml',price:8,img:IMAGES.coke},{name:'Coca-Cola Lata Zero 350ml',price:8,img:IMAGES.cokeZero}],friesAddon={name:'Fritas 150g',price:11.9,img:IMAGES.fries};
function comboDrinkGroup(group,label){return `<div class="custom-group"><div class="custom-label"><span>${label}</span><em class="required-tag">Obrigatório</em></div><div class="custom-options">${drinkChoices.map(drink=>`<label class="custom-option"><input type="radio" name="${group}" value="${drink.name}"><img class="option-thumb" src="${drink.img}" alt="${drink.name}"><span><b>${drink.name}</b><small>Inclusa no combo</small></span></label>`).join('')}</div></div>`}
function customizationHtml(product){if(product.cat==='combos'){const groups=product.id==='c3'?comboDrinkGroup('comboDrink1','Escolha a bebida 1')+comboDrinkGroup('comboDrink2','Escolha a bebida 2'):comboDrinkGroup('comboDrink1','Escolha a bebida do combo');return `<div class="customization"><h4>Escolha as bebidas</h4><p>${product.id==='c3'?'Selecione duas opções. Você pode repetir o mesmo sabor.':'Selecione uma opção para completar o combo.'}</p>${groups}</div>`}if(product.cat==='burguers'){return `<div class="customization"><h4>Complete seu burger</h4><p>Os adicionais são opcionais.</p><div class="custom-group"><div class="custom-label"><span>Bebida</span><span>Opcional</span></div><div class="custom-options"><label class="custom-option"><input type="radio" name="burgerDrink" value="" data-price="0" checked onchange="updateProductPrice()"><span><b>Sem bebida</b><small>Não adicionar</small></span></label>${drinkChoices.map(drink=>`<label class="custom-option"><input type="radio" name="burgerDrink" value="${drink.name}" data-price="${drink.price}" onchange="updateProductPrice()"><img class="option-thumb" src="${drink.img}" alt="${drink.name}"><span><b>${drink.name}</b><small>+ ${brl(drink.price)}</small></span></label>`).join('')}</div></div><div class="custom-group"><div class="custom-label"><span>Acompanhamento</span><span>Opcional</span></div><div class="custom-options"><label class="custom-option"><input class="burger-addon" type="checkbox" value="${friesAddon.name}" data-price="${friesAddon.price}" onchange="updateProductPrice()"><img class="option-thumb food" src="${friesAddon.img}" alt="${friesAddon.name}"><span><b>${friesAddon.name}</b><small>+ ${brl(friesAddon.price)}</small></span></label></div></div></div>`}return''}
function updateProductPrice(){if(!selected)return;let extra=0;if(selected.cat==='burguers'){const drink=document.querySelector('input[name="burgerDrink"]:checked');extra+=Number(drink?.dataset.price||0);document.querySelectorAll('.burger-addon:checked').forEach(input=>extra+=Number(input.dataset.price||0))}const price=document.getElementById('modalPrice');if(price)price.textContent=brl(selected.price+extra)}
function openProduct(id) {
  selected = products.find(product => product.id === id);
  if (!selected) return;
  const body = document.getElementById('productBody');
  body.innerHTML = `<img class="product-modal-img ${selected.cat === 'bebidas' ? 'contain' : ''}" src="${selected.img}" alt="${selected.name}">
    <h3>${selected.name}</h3><p>${selected.desc}</p>${customizationHtml(selected)}
    <div class="field"><label for="itemNote">OBSERVAÇÃO DESTE ITEM</label>
    <textarea id="itemNote" maxlength="250" placeholder="Ex.: sem cebola, ponto da carne..."></textarea></div>`;
  body.scrollTop = 0;
  updateProductPrice();
  showLayer('productModal');
}

function addSelected() {
  if (!selected) return;
  const note = document.getElementById('itemNote').value.trim();
  const options = [];
  let extra = 0;

  if (selected.cat === 'combos') {
    const totalChoices = selected.id === 'c3' ? 2 : 1;
    for (let number = 1; number <= totalChoices; number++) {
      const drinks = [...document.querySelectorAll(`input[name="comboDrink${number}"]`)];
      const drink = drinks.find(input => input.checked);
      if (!drink) {
        const group = drinks[0].closest('.custom-group');
        group.classList.add('choice-missing');
        group.scrollIntoView({ block: 'nearest' });
        drinks[0].focus({ preventScroll: true });
        toast(totalChoices === 2 ? `Escolha a bebida ${number}` : 'Escolha a bebida do combo');
        return;
      }
      options.push(`${totalChoices === 2 ? 'Bebida ' + number : 'Bebida'}: ${drink.value}`);
    }
  }

  if (selected.cat === 'burguers') {
    const drink = document.querySelector('input[name="burgerDrink"]:checked');
    if (drink?.value) {
      options.push(`Bebida: ${drink.value}`);
      extra += Number(drink.dataset.price);
    }
    for (const addon of document.querySelectorAll('.burger-addon:checked')) {
      options.push(addon.value);
      extra += Number(addon.dataset.price);
    }
  }

  const optionText = options.join(' • ');
  const unitPrice = selected.price + extra;
  const signature = JSON.stringify([selected.id, optionText, note]);
  const found = cart.find(item => item.signature === signature && item.unitPrice === unitPrice);
  if (found) {
    found.qty++;
  } else {
    cart.push({ key: 'item-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
      signature, id: selected.id, qty: 1, note, options: optionText, unitPrice });
  }
  save();
  closeProduct();
  toast('Adicionado ao carrinho');
}
function consult(id){const p=products.find(x=>x.id===id);openWhats(`Olá! Qual é o valor atual do combo “${p.name}”?`)}
function save() {
  try {
    localStorage.setItem('vice-cart', JSON.stringify(cart));
  } catch {
    // Keep the current cart available even if the browser blocks persistence.
  }
  renderCart();
}
function changeQty(key,delta){const item=cart.find(i=>i.key===key);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(i=>i.key!==key);save()}
function removeItem(key){cart=cart.filter(i=>i.key!==key);save()}
function itemUnitPrice(item){const product=products.find(p=>p.id===item.id);return Number.isFinite(item.unitPrice)?item.unitPrice:product.price}
function total(){return cart.reduce((sum,item)=>sum+itemUnitPrice(item)*item.qty,0)}
function renderCart(){const count=cart.reduce((s,i)=>s+i.qty,0);document.getElementById('cartCount').textContent=count;const body=document.getElementById('cartBody'),foot=document.getElementById('cartFoot');if(!cart.length){body.innerHTML='<div class="cart-empty"><div class="bag">🍔</div><h3>Seu carrinho está vazio</h3><p>Escolha seus favoritos e eles aparecem aqui.</p></div>';foot.innerHTML='';return}body.innerHTML=cart.map(i=>{const p=products.find(x=>x.id===i.id),details=[i.options?`<span class="cart-option">${esc(i.options)}</span>`:'',i.note?`<span class="cart-option">Obs.: ${esc(i.note)}</span>`:''].join('')||'Sem observações';return `<div class="cart-line"><img class="${p.cat==='bebidas'?'contain':''}" src="${p.img}" alt=""><div><div class="cart-name">${p.name}</div><div class="cart-note">${details}</div><div class="qty"><button onclick="changeQty('${i.key}',-1)">−</button><b>${i.qty}</b><button onclick="changeQty('${i.key}',1)">+</button></div></div><div style="text-align:right"><b>${brl(itemUnitPrice(i)*i.qty)}</b><br><button class="remove" onclick="removeItem('${i.key}')">remover</button></div></div>`}).join('');foot.innerHTML=`<div class="summary-row"><span>Subtotal</span><b>${brl(total())}</b></div><div class="summary-row"><span>Entrega</span><b style="color:var(--green)">Grátis</b></div><div class="summary-row total"><span>Total</span><span>${brl(total())}</span></div><button class="primary checkout" onclick="openCheckout()">Finalizar Pedido</button>`}
let activeLayer = null;
let returnFocus = null;

function showLayer(id) {
  if (id === activeLayer) return;
  if (!activeLayer) returnFocus = document.activeElement;
  activeLayer = id;
  for (const layer of document.querySelectorAll('#cart, #productModal, #checkoutModal')) {
    layer.inert = layer.id !== id;
    layer.classList.toggle('show', layer.id === id);
  }
  for (const element of document.querySelectorAll('.hero, .sticky, #menu, #mobileCartBar')) {
    element.inert = Boolean(id);
  }
  document.getElementById('backdrop').classList.toggle('show', Boolean(id));
  document.body.style.overflow = id ? 'hidden' : '';
  if (id) {
    document.getElementById('toast').classList.remove('show');
    const layer = document.getElementById(id);
    layer.scrollTop = 0;
    layer.querySelector('h2').focus({ preventScroll: true });
  } else {
    returnFocus?.focus({ preventScroll: true });
    returnFocus = null;
  }
}

function toggleCart(show) { showLayer(show ? 'cart' : null); }
function closeProduct() { selected = null; showLayer(null); }
function openCheckout() { if (cart.length) showLayer('checkoutModal'); }
function closeCheckout() { showLayer(null); }
function closeLayers() { selected = null; showLayer(null); }

let cepRequest;
let autoAddress;
const cepHint = 'Busque pelo CEP ou preencha o endereço abaixo.';

function setCepStatus(message, kind = '') {
  const status = document.getElementById('cepStatus');
  status.className = 'cep-status' + (kind ? ' ' + kind : '');
  status.textContent = message;
}

function maskCep(input) {
  const digits = input.value.replace(/\D/g, '').slice(0, 8);
  input.value = digits.length > 5 ? digits.slice(0, 5) + '-' + digits.slice(5) : digits;
  if (autoAddress && autoAddress.cep !== digits) {
    for (const [id, previousValue] of Object.entries(autoAddress.fields)) {
      const field = document.getElementById(id);
      if (field.value === previousValue) field.value = '';
    }
    autoAddress = null;
  }
  cepRequest?.abort();
  cepRequest = null;
  const button = document.getElementById('cepButton');
  button.disabled = false;
  button.textContent = 'Buscar CEP';
  setCepStatus(cepHint);
}

async function lookupCep() {
  if (cepRequest) return;
  const input = document.getElementById('cep');
  const cep = input.value.replace(/\D/g, '');
  if (cep.length !== 8) {
    setCepStatus('Digite os 8 números do CEP.', 'error');
    input.focus();
    return;
  }
  const button = document.getElementById('cepButton');
  const fields = { street: 'logradouro', neighborhood: 'bairro', city: 'localidade', state: 'uf' };
  const originalValues = Object.fromEntries(
    Object.keys(fields).map(id => [id, document.getElementById(id).value])
  );
  const request = new AbortController();
  cepRequest = request;
  const timer = setTimeout(() => request.abort(), 6000);
  button.disabled = true;
  button.textContent = 'Buscando...';
  setCepStatus('Consultando endereço...');

  try {
    const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`, { signal: request.signal });
    if (!response.ok) throw new Error('Falha na consulta');
    const data = await response.json();
    if (cepRequest !== request || input.value.replace(/\D/g, '') !== cep) return;
    if (data.erro) {
      setCepStatus('CEP não encontrado. Você pode preencher o endereço manualmente.', 'error');
      return;
    }
    const autofilled = autoAddress?.cep === cep ? { ...autoAddress.fields } : {};
    for (const [id, key] of Object.entries(fields)) {
      const field = document.getElementById(id);
      if (field.value === originalValues[id] && data[key]) {
        field.value = data[key];
        autofilled[id] = data[key];
      }
    }
    autoAddress = { cep, fields: autofilled };
    setCepStatus('Confira o endereço e preencha os campos que faltam.', 'success');
  } catch {
    if (cepRequest === request) setCepStatus('Consulta indisponível. Preencha o endereço manualmente.', 'error');
  } finally {
    clearTimeout(timer);
    if (cepRequest === request) {
      cepRequest = null;
      button.disabled = false;
      button.textContent = 'Buscar CEP';
    }
  }
}
function selectPayment(input){document.getElementById('payment').value=input.value;document.querySelectorAll('.payment-option').forEach(option=>option.classList.toggle('active',option.contains(input)));togglePix()}
function togglePix(){const pay=document.getElementById('payment').value;document.getElementById('pixBox').style.display=pay==='Pix'?'flex':'none';document.getElementById('changeField').style.display=pay==='Dinheiro'?'block':'none'}
async function copyPix() {
  try {
    await navigator.clipboard.writeText('05940569935');
    toast('Chave Pix copiada!');
  } catch {
    toast('Pix: 05940569935');
  }
}

function sendOrder(event) {
  event.preventDefault();
  if (!cart.length) {
    closeCheckout();
    toast('Adicione um item para fazer seu pedido.');
    return;
  }
  const form = document.getElementById('checkoutForm');
  if (!form.reportValidity()) return;

  const value = id => document.getElementById(id).value.trim();
  const payment = form.querySelector('input[name="paymentChoice"]:checked').value;
  const address = [value('street'), value('number'), value('neighborhood'), value('addressComplement'),
    `${value('city')} - ${value('state').toUpperCase()}`, `CEP ${value('cep')}`].filter(Boolean).join(', ');
  const lines = cart.map((item, index) => {
    const product = products.find(product => product.id === item.id);
    const details = [item.options, item.note ? 'Obs.: ' + item.note : ''].filter(Boolean);
    return [`${index + 1}. ${item.qty}x ${product.name} — ${brl(itemUnitPrice(item) * item.qty)}`,
      ...details.map(detail => '   ' + detail)].join('\n');
  }).join('\n');
  const message = [
    '🍔 *NOVO PEDIDO — VICE BURGUER*',
    `Olá! Meu nome é *${value('customer')}*.`,
    lines,
    `*Subtotal:* ${brl(total())}\n*Entrega:* Grátis\n*TOTAL:* ${brl(total())}`,
    [
      '*Recebimento:* Entrega',
      `*Endereço:* ${address}`,
      `*Pagamento:* ${payment}`,
      payment === 'Dinheiro' && value('change') ? `*Troco para:* ${value('change')}` : '',
      value('orderNotes') ? `*Observações gerais:* ${value('orderNotes')}` : '',
    ].filter(Boolean).join('\n'),
    'Tempo estimado informado: 45–55 min.',
  ].join('\n\n');
  openWhats(message);
}

function openWhats(text) {
  const query = new URLSearchParams({ text });
  window.location.assign('https://wa.me/5541995484887?' + query);
}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}
function scrollMenu(){document.getElementById('menu').scrollIntoView({behavior:'smooth'})}
function syncMobileCart(){const count=cart.reduce((sum,item)=>sum+item.qty,0),bar=document.getElementById('mobileCartBar');bar.classList.toggle('is-visible',count>0);bar.setAttribute('aria-hidden',count?'false':'true');document.getElementById('mobileCartLabel').textContent=`${count} ${count===1?'item':'itens'}`;document.getElementById('mobileCartTotal').textContent=brl(total());document.getElementById('mobileCartAction').innerHTML='Resumo do Pedido <span>→</span>'}
new MutationObserver(syncMobileCart).observe(document.getElementById('cartCount'),{childList:true,characterData:true,subtree:true});setTimeout(syncMobileCart,0);
document.querySelectorAll('.chip').forEach(button=>button.addEventListener('click',()=>{setActiveCategory(button.dataset.category);document.getElementById(button.dataset.category)?.scrollIntoView({behavior:'smooth',block:'start'})}));
window.addEventListener('scroll',updateCategoryJourney,{passive:true});window.addEventListener('resize',updateCategoryJourney);
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeLayers()});status();setInterval(status,60000);renderMenu();renderCart();togglePix();updateCategoryJourney();
document.getElementById('productBody').addEventListener('change', event => {
  event.target.closest('.choice-missing')?.classList.remove('choice-missing');
});

// Event attributes in the HTML and product templates call these handlers.
Object.assign(window, {
  toggleCart,
  closeLayers,
  closeProduct,
  closeCheckout,
  sendOrder,
  maskCep,
  lookupCep,
  selectPayment,
  copyPix,
  openProduct,
  consult,
  updateProductPrice,
  addSelected,
  changeQty,
  removeItem,
  openCheckout,
});
